#ifndef AUTO_BENCHMARK_BENCHMARK_H
#define AUTO_BENCHMARK_BENCHMARK_H

extern void runBenchmarks();

#endif
