#ifndef COMPARISON_BENCHMARK_BENCHMARK_H
#define COMPARISON_BENCHMARK_BENCHMARK_H

extern void runBenchmarks();

#endif
