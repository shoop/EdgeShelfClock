var searchData=
[
  ['ntpclock_265',['NtpClock',['../classace__time_1_1clock_1_1NtpClock.html',1,'ace_time::clock']]]
];
