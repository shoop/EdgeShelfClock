var searchData=
[
  ['negate_401',['negate',['../time__period__mutation_8h.html#aa3c982884e48ebe3ac7a676f70c5e391',1,'ace_time::time_period_mutation']]],
  ['ntpclock_402',['NtpClock',['../classace__time_1_1clock_1_1NtpClock.html#a05433c1de230ee9e7b4b36a6c9f49e04',1,'ace_time::clock::NtpClock']]]
];
