var searchData=
[
  ['offsetminutes_496',['offsetMinutes',['../structace__time_1_1basic_1_1Transition.html#a124381c8110113623dfa676885ff4331',1,'ace_time::basic::Transition::offsetMinutes()'],['../structace__time_1_1extended_1_1Transition.html#a087a733dd46c922bc47780aba66e36c3',1,'ace_time::extended::Transition::offsetMinutes()']]],
  ['originaltransitiontime_497',['originalTransitionTime',['../structace__time_1_1extended_1_1Transition.html#a5412a754b542c77797fa6e5906505d03',1,'ace_time::extended::Transition']]]
];
