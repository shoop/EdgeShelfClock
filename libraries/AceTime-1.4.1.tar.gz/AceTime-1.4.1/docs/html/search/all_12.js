var searchData=
[
  ['untildatetime_220',['untilDateTime',['../structace__time_1_1extended_1_1ZoneMatch.html#adb5aada25ad9a3768d4bde754b3f4cca',1,'ace_time::extended::ZoneMatch::untilDateTime()'],['../structace__time_1_1extended_1_1Transition.html#ac63fcc948ca1e8157bb93ade38c26003',1,'ace_time::extended::Transition::untilDateTime()']]]
];
