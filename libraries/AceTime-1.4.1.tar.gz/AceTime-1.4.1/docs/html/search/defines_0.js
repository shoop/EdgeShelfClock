var searchData=
[
  ['ace_5ftime_5fuse_5fprogmem_508',['ACE_TIME_USE_PROGMEM',['../compat_8h.html#a736a584901fd7e4d3c06ade513afd259',1,'compat.h']]]
];
