var searchData=
[
  ['startdatetime_499',['startDateTime',['../structace__time_1_1extended_1_1ZoneMatch.html#aa28c802edb9fbfca7decac19b5e316b0',1,'ace_time::extended::ZoneMatch::startDateTime()'],['../structace__time_1_1extended_1_1Transition.html#aa02b144398b9faa503f3d3677e411b8b',1,'ace_time::extended::Transition::startDateTime()']]],
  ['startepochseconds_500',['startEpochSeconds',['../structace__time_1_1basic_1_1Transition.html#a51b6a6da0be1647e1fa9702270beebca',1,'ace_time::basic::Transition::startEpochSeconds()'],['../structace__time_1_1extended_1_1Transition.html#a455d7d971489040388fb4750d2b93939',1,'ace_time::extended::Transition::startEpochSeconds()']]]
];
