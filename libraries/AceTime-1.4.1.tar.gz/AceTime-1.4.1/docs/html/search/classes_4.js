var searchData=
[
  ['hardwaredatetime_258',['HardwareDateTime',['../structace__time_1_1hw_1_1HardwareDateTime.html',1,'ace_time::hw']]],
  ['hardwaretemperature_259',['HardwareTemperature',['../structace__time_1_1hw_1_1HardwareTemperature.html',1,'ace_time::hw']]]
];
