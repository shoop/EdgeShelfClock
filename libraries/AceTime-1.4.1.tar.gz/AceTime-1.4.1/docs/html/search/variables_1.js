var searchData=
[
  ['deltaminutes_455',['deltaMinutes',['../structace__time_1_1basic_1_1Transition.html#a261c010379de16856415a5d675395d24',1,'ace_time::basic::Transition::deltaMinutes()'],['../structace__time_1_1extended_1_1Transition.html#a3e72596e313327e621489c5cc507c5a3',1,'ace_time::extended::Transition::deltaMinutes()']]]
];
