var searchData=
[
  ['timingstats_89',['TimingStats',['../classace__common_1_1TimingStats.html#a8ffb99931928b622e696addddf426b96',1,'ace_common::TimingStats::TimingStats()'],['../classace__common_1_1TimingStats.html#a7dfa7d8de54f34a9d3e32a4040d7884f',1,'ace_common::TimingStats::TimingStats(const TimingStats &amp;)=default']]]
];
